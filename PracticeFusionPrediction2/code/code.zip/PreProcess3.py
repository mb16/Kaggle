#!/usr/bin/env python

import csv_io
import math

from math import log
import string
from sklearn.ensemble import RandomForestClassifier

def toFloat(str):
	return float(str)


def PreProcess3():


	trainBase = csv_io.read_data("PreProcessData/training_PreProcess2.csv", False)
	test = csv_io.read_data("PreProcessData/test_PreProcess2.csv", False)

	target = [x[0] for x in trainBase]
	train = [x[1:] for x in trainBase]
				
	
	DataClassList = csv_io.read_data("PreProcessData/DataClassList.csv", False)
	
	#for myIndex in range(2,8):	# use for quick processing, and only training the most critical features
	for myIndex in range(2,75): # train most critical features (longer processing)
	#for myIndex in range(2,len(train[0]) - 2): # train all features ( can take a long time)
		
		
		MTrain = []
		FTrain = []
		MTarget = []
		FTarget = []
		
		for index, data in enumerate(train):
			if ( data[0] == "0" ):
				MTrain.append([data[1], data[myIndex]])
				MTarget.append(target[index])
				#print "M", data[1], data[myIndex]
			if ( data[0] == "1" ):
				FTrain.append([data[1], data[myIndex]])	
				FTarget.append(target[index])
				#print "F", data[1], data[myIndex]
				
		
		#print len(MTrain), len(FTrain),len(MTarget), len(FTarget)

		# better than GradBoost, and much better than KNN, should tune.
		Mneigh = RandomForestClassifier()
		Fneigh = RandomForestClassifier()

		Mneigh.fit(MTrain, MTarget) 
		Fneigh.fit(FTrain, FTarget) 
		


		for index, data in enumerate(train):
			if ( data[0] == "0" ):
				pred = Mneigh.predict_proba([data[1], data[myIndex]])
				#print "M", data[1], data[myIndex], pred[0][1], target[index]
				trainBase[index].append(pred[0][1])
			if ( data[0] == "1" ):
				pred = Fneigh.predict_proba([data[1], data[myIndex]])
				#print "F", data[1], data[myIndex], pred[0][1], target[index]
				trainBase[index].append(pred[0][1])


		
		for index, data in enumerate(test):
			if ( data[0] == "0" ):
				pred = Mneigh.predict_proba([data[1], data[myIndex]])
				#print "M", data[1], data[myIndex], pred[0][1], target[index]
				test[index].append(pred[0][1])
			if ( data[0] == "1" ):
				pred = Fneigh.predict_proba([data[1], data[myIndex]])
				#print "F", data[1], data[myIndex], pred[0][1], target[index]
				test[index].append(pred[0][1])	
		

		print "Processing Feature Index: ", myIndex, " of ", len(train[0])	
	
	
		with open("PreProcessData/DataClassList.csv", "a") as myfile:
			myfile.write("RF_Gender-Age-Class_" + str(DataClassList[myIndex][0]) + "_" + str(myIndex) + "\n")

	print "Writing Data"
	csv_io.write_delimited_file("PreProcessData/training_PreProcess3.csv", trainBase)		
	csv_io.write_delimited_file("PreProcessData/test_PreProcess3.csv", test)
	print "Done."	


	
		
if __name__=="__main__":

	print
	print "WARNING: This program appends features to the existing files. Do no run this more than once, otherwise redundant features will be appended to the list."
	print
	
	# need to add new line at end of file before appending data.
	#with open("PreProcessData/DataClassList.csv", "a") as myfile:
	#	myfile.write("\n")

	print "Creating Gender-Age-XFeature based class probabilities."
	PreProcess3()
